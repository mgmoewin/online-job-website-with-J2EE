-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: job
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `com_id` int NOT NULL AUTO_INCREMENT,
  `com_name` varchar(45) NOT NULL,
  `com_add` varchar(45) NOT NULL,
  `com_ph` varchar(45) NOT NULL,
  `com_email` varchar(45) NOT NULL,
  `com_web` varchar(45) NOT NULL,
  `image` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (8,'GWY','Mawlamyine','09681247460','gwy@gmail.com','www.gwy.com','photo_2023-09-09_03-28-04.jpg'),(13,'Triple Wine','Mawlamyine','09767692358','thetpaing@gmail.com','www.triplewine.com','photo_2023-09-09_20-23-45.jpg'),(14,'eCuppaHeaven','Thaton , Gort','09793373874','ecuppaheaven@gamil.com','www.eCuppaHeaven.com','photo_2023-09-09_22-03-59.jpg'),(15,'Good Number 1','Yangon','09775512824','good1@gmail.com','www.good1.com','good1.jpg'),(16,'Medconnect','Mandalay','09766187984','aungmyokyaw@gmail.com','www.heartconnect.com','photo_2023-09-10_22-40-02.jpg'),(17,'WaToke OS','Naungkalar','09766187984','watoke@gmail.com','www.watoke.com','logo.png'),(18,'WaToke OS','Naungkalar','09766187984','watoke@gmail.com','www.watoke.com','logo.png');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `job_id` int NOT NULL AUTO_INCREMENT,
  `job_name` varchar(45) NOT NULL,
  `job_type` varchar(45) NOT NULL,
  `salary` int NOT NULL,
  `position` varchar(45) NOT NULL,
  `deg` varchar(45) NOT NULL,
  `age` int NOT NULL,
  `qty` int NOT NULL,
  `gender` varchar(45) NOT NULL,
  `exp` int NOT NULL,
  `image` varchar(300) DEFAULT NULL,
  `add` varchar(45) NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES (8,'Edu','Full Time',500000,'Instructor','B.Sc',28,1,'Female',2,'photo_2023-09-09_03-28-04.jpg','Mawlamyine'),(13,'Art & Desgin','Full Time',500000,'Manager','B.A',26,1,'Female',2,'photo_2023-09-09_20-23-45.jpg','Mawlamyine'),(14,'Resturant','Part time',450000,'Manager','B.Com',25,1,'male',2,'photo_2023-09-09_22-03-59.jpg','Thaton'),(15,'IT','Part Time',700000,'Java Developer','B.Sc',29,2,'male',2,'good1.jpg','Yangon'),(16,'Doctor','Part Time',1000000,'Surgeon','MBBS',35,1,'Male',2,'photo_2023-09-10_22-40-02.jpg','Mandalay'),(17,'OS','full time ',300000,'Page Admin','B.Sc',25,2,'Male,Female',2,'logo.png','Naungkalar'),(18,'OS','full time ',300000,'Accountant','B.Sc',25,2,'female',2,'logo.png','Naungkalar');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package`
--

DROP TABLE IF EXISTS `package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package` (
  `email` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  `time` varchar(45) NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package`
--

LOCK TABLES `package` WRITE;
/*!40000 ALTER TABLE `package` DISABLE KEYS */;
INSERT INTO `package` VALUES ('aung@gmail.com','002','2','true'),('aungmyittun@gmail.com','001','2','true'),('ayeminsan@gmail.com','ayeminsan@gmail.com002','2','true'),('ei@gmail.com','002','1','true'),('eiwin@gmail.com','005','3','true'),('moewin@gmail.com','007','3','true'),('pyae@gmail.com','008','3','true'),('pyaephonekhaung@gmail.com','003','2','true'),('pyaephyo@gmail.com','009','3','true'),('pyaephyoaung@gmail.com','006','2','true'),('seinmoe@gmail.com','010','3','true'),('thetpaing@gmail.com','002','3','true'),('thetpaing252699@gmail.com','002','2','true'),('zawhtutoo@gmail.com','zawzaw12','3','true');
/*!40000 ALTER TABLE `package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `birth_day` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (11,'Thet Paing','thetpaing@gmail.com','thetpaing002',NULL,NULL,'User'),(12,'aungmyittun','aungmyittun@gmail.com','aungmyittun',NULL,NULL,'Company'),(13,'Thet Paing ','thetpaing252699@gmail.com','thetpaing',NULL,NULL,'Company'),(14,'Pyae ','pyaephonekhaung@gmail.com','pyaephone',NULL,NULL,'Company'),(15,'Sein Moe Lone','seinmoe@gmail.com','seinmoelone',NULL,NULL,'User'),(16,'moe win','moewin@gmail.com','moewin142',NULL,NULL,'User'),(17,'pyae phyo','pyaephyo@gmail.com','pyaephyo',NULL,NULL,'User'),(18,'aungmyokyaw','aungmyokyaw@gmail.com','aungmyokyaw',NULL,NULL,'User'),(19,'pyaephyo','pyae@gmail.com','pyaephyoaung',NULL,NULL,'Company'),(20,'ayeminsan','ayeminsan@gmail.com','ayeminsan',NULL,NULL,'Company'),(21,'Ei Win','eiwin@gmail.com','eithandarwin',NULL,NULL,'User'),(22,'pyae','pyaephyoaung@gmail.com','12345678',NULL,NULL,'Company'),(23,'Zaw Htut Oo','zawhtutoo@gmail.com','zawzaw12',NULL,NULL,'Company'),(24,'aung ','aung@gmail.com','12345678',NULL,NULL,'Company'),(25,'ei win','ei@gmail.com','12345678',NULL,NULL,'User');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-12 10:18:43

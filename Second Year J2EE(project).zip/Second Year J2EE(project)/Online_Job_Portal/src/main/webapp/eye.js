/*co
nst eyeicon=document.querySelector("#eyeicon");
const pass=document.querySelector("#pass");

eyeicon.addEventListener("click", function(){
	this.classList.toggle("fa-eye-slash");
	const type=passwordField.getAttribute("type")
	=== "password" ? "text" : "pass";
	
	pass.setAttribute("type",type);
	
	})*/
	
	
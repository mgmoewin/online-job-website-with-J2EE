


const singupbtnlink =document.querySelector('.signUpBtn-link');
const singinbtnlink =document.querySelector('.signInBtn-link');
const wrapper =document.querySelector('.wrapper');

 singupbtnlink.addEventListener('click',() => {
	wrapper.classList.toggle('active');
});
singinbtnlink.addEventListener('click',() => {
	wrapper.classList.toggle('active');
});


var passField=document.querySelector("input");
	var btn=document.querySelector("span i");

	btn.onclick = function (){
		if(passField.type === "password"){
		passField.type ="text";	
	}
	else{
		passField.type= "password";
	}}